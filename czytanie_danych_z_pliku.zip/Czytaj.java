import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Czytaj
{
	private static boolean Check(Character c)
	{
		if (c == '\t' || c == '\n' || c == '\f' || c == '\r' || c == ' ')
			return false;
		return true;
	}

	public static void main(String[] args) throws FileNotFoundException
	{
		Set<String> words = new TreeSet<>();
		File file = new File("plik.txt");
		Scanner input = new Scanner(file);

		while (input.hasNextLine())
		{
			String linia = input.nextLine();
			Integer limit = linia.length();
			for (int i = 0; i < limit; i++)
			{
				if (Check(linia.charAt(i)))
				{
					String str = new String();
					while ((i < limit) && Check(linia.charAt(i)))
					{
						str = str + linia.charAt(i);
						i++;
					}
					words.add(str);
				}
			}
		}
		for(String w : words)
		{
 			System.out.println(w);
 		}
	}
}