import java.util.Scanner;

public class Sito
{
	public static int[] wyzn_pierwsze(int n)
	{
		boolean[] zl = new boolean[n + 5];
		for (int i = 2; i * i <= n; i++)
		{
			for (int j = i * i; j <= n; j += i)
				zl[j] = true;
		}
		int ile = 0;
		for (int i = 2; i <= n; i++)
		{
			if (zl[i] == false)
				ile++;
		}
		int[] wyn = new int[ile];
		ile = 0;
		for (int i = 2; i <= n; i++)
		{
			if (zl[i] == false)
				wyn[ile++] = i;
		}
		return wyn;
	}

	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		int[] pierwsze = wyzn_pierwsze(scan.nextInt());
		for (int i = 0; i < pierwsze.length; i++)
			System.out.print(pierwsze[i] + " ");
	}
}