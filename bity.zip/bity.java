import java.util.Scanner;

class bity {
	public static void main(String args[])  
	{
        Scanner scanner = new Scanner(System.in);
        Long nr = scanner.nextLong();
		bit(nr);
	}
	private static void bit (long limit)
	{
        long dod_ans = 0;
        long ans = 0;
		long licznik = -1;
		while(limit != 0)
		{
			licznik++;
			long pom = limit & 1L;
            limit /= 2;
			if (pom == 1)
			{
                ans += dod_ans;
				ans = ans + (((1L << licznik) * licznik) >> 1L);
				ans++;
                dod_ans = dod_ans + (1L << licznik);
			}
		}
		System.out.println(ans);
		
	}
} 