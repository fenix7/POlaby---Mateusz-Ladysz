import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class Czytaj2
{
	private static boolean Check(Character c)
	{
		if (c == '\t' || c == '\n' || c == '\f' || c == '\r' || c == ' ')
			return false;
		return true;
	}

	public static void main(String[] args) throws FileNotFoundException //funkcja wypisujaca slowa wraz z wierszami, w ktorych wystepuja z pliku "plik.txt"
	{
		Set<String> words = new TreeSet<>();
		Map<String, ArrayList<Integer> > mapa = new TreeMap<>();
		File file = new File("plik.txt");
		Scanner input = new Scanner(file);
		Integer ind = 0;
		while (input.hasNextLine())
		{
			ind++;
			String linia = input.nextLine();
			Integer limit = linia.length();
			for (int i = 0; i < limit; i++)
			{
				if (Check(linia.charAt(i)))
				{
					String str = new String();
					while ((i < limit) && Check(linia.charAt(i)))
					{
						str = str + linia.charAt(i);
						i++;
					}

					ArrayList<Integer> lista;
					if (words.contains(str))
						lista = mapa.get(str);
					else lista = new ArrayList<Integer>();
					lista.add(ind);
					mapa.put(str, lista);
					words.add(str);
				}
			}
		}
		for(String w : words)
		{
 			System.out.print(w + " : ");
 			ArrayList<Integer> l = mapa.get(w);
 			Integer lim = l.size();
 			for (int i = 0; i < lim; i++)
 				System.out.print(l.get(i) + " ");
 			System.out.println();
 		}
	}
}