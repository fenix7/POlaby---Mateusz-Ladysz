import java.util.Scanner;

public class Fib
{
	public static long n_ta(long n)
	{
		long v1 = 0;
		long v2 = 1;
		for (long i = 2; i <= n; i++)
		{
			long pom = v2;
			v2 += v1;
			v1 = pom;
		}
		return v2;
	}
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.println(n_ta(scan.nextLong()));
	}
}