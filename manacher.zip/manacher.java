class manacher {  
	public static void main(String args[])  
	{    
	 	man("bgcaacgb");
	}
	private static void man (String s)
	{
		int ans = 0;
		int dl = s.length();
		int[] tab = new int[dl + 5];
		s = "*" + s + "&";
		int i = 1;
		while (i <= dl)
		{
			while (s.charAt(i - ans) == s.charAt(i + ans + 1)) ans++;
			int j = 1;
			tab[i] = ans;
			while (tab[i - j] != tab[i] - j && j <= ans)
			{
				tab[i + j] = Math.min (tab[i - j], tab[i] - j);
				j++;
			}
			ans = Math.max (ans - j, 0);
			i += j;
		}
		System.out.println ("Promienie palindromow dlugosci parzystej :");
		i = 1;
		while (i <= dl)
		{
			System.out.print (tab[i]);
			System.out.print (" ");
			i++;
		}
		System.out.println ("");
		ans = 0;
		i = 1;
		while (i <= dl)
		{
			while (s.charAt(i - ans - 1) == s.charAt(i + ans + 1)) ans++;
			int j = 1;
			tab[i] = ans;
			while (tab[i - j] != tab[i] - j && j <= ans)
			{
				tab[i + j] = Math.min (tab[i - j], tab[i] - j);
				j++;
			}
			ans = Math.max (ans - j, 0);
			i += j;
		}
		System.out.println ("Promienie palindromow dlugosci nieparzystej :");
		i = 1;
		while (i <= dl)
		{
			System.out.print (tab[i]);
			System.out.print (" ");
			i++;
		}
		
	}
} 
