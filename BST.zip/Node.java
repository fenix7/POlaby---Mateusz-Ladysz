public class Node<T1 extends Comparable<T1>>
{
	private Node<T1> left;
	private Node<T1> right;
	private T1 val;
	private Integer height;

	public Node(Node<T1> l, T1 val, Node<T1> r, Integer h)
	{
		this.left = l;
		this.val = val;
		this.right = r;
		this.height = h;
	}

	public Node<T1> getLeft()
	{
		return this.left;
	}

	public void setLeft(Node<T1> l)
	{
		this.left = l;
	}

	public Node<T1> getRight()
	{
		return this.right;
	}

	public void setRight(Node<T1> r)
	{
		this.right = r;
	}

	public T1 getVal()
	{
		return this.val;
	}

	public void setVal(T1 v)
	{
		this.val = v;
	}

	public Integer getHeight()
	{
		return this.height;
	}

	public void setHeight(Integer h)
	{
		this.height = h;
	}



}