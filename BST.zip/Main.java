public class Main
{
	public static void main(String[] args)
	{
		Bst tree = new Bst();
		System.out.println(tree.getRoot());
		tree.Add("a");
		tree.Add("b");
		tree.Add("c");
		tree.Remove("a");



		tree.Print();
	}
}
