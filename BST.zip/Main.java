public class Main
{
	public static void main(String[] args)
	{
		//przyklad wywolania funkcji add, remove, print
		Bst<String> tree = new Bst<String>();
		System.out.println();

		tree.Add("a");
		tree.Print();
		System.out.println();

		tree.Add("b");
		tree.Print();
		System.out.println();

		tree.Add("c");
		tree.Print();
		System.out.println();

		tree.Remove("a");
		tree.Print();
		System.out.println();

		tree.Add("a");
		tree.Print();
		System.out.println();

		tree.Add("a");
		tree.Print();
		System.out.println();

		tree.Add("abb");
		tree.Print();
		System.out.println();

		tree.Remove("b");
		tree.Print();
		System.out.println();

		tree.Add("b");
		tree.Print();
		System.out.println();

		tree.Remove("abb");
		tree.Print();
		System.out.println();

		tree.Remove("a");
		tree.Print();
		System.out.println();

		tree.Remove("c");
		tree.Print();
		System.out.println();

		tree.Remove("b");
		tree.Print();
		System.out.println();

		tree.Remove("a");
		tree.Print();
		System.out.println();

		tree.Add("l");
		tree.Print();
		System.out.println();

		tree.Remove("lll");
		tree.Print();
		System.out.println();



		tree.Print();
	}
}
