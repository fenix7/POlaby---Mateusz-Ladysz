public class Bst<T1 extends Comparable<T1>>
{
	private Node<T1> root;

	public Bst()
	{
		this.root = null;
	}

	private Node<T1> getRoot()
	{
		return this.root;
	}

	private void setRoot(Node<T1> r)
	{
		this.root = r;
	}

	private Integer Max(Integer a, Integer b)
	{
		if (a > b)
			return a;
		else return b;
	}

	private Integer Height(Node<T1> akt)
	{
		if (akt == null)
			return 0;
		else return akt.getHeight();
	}

	private Node<T1> Make(Node<T1> l, T1 v, Node<T1> r)
	{
		Node<T1> nn = new Node<T1>(l, v, r, Max(Height(l), Height(r)) + 1);
		return nn;
	}

	private Node<T1> Balance(Node<T1> l, T1 v, Node<T1> r)
	{
		Integer hl = Height(l);
		Integer hr = Height(r);
		if (hr > hl + 1)
		{
			T1 rv = (T1)r.getVal();
			Node<T1> rl = r.getLeft();
			Node<T1> rr = r.getRight();
			if (Height(rr) >= Height(rl))
				return Make(Make(l, v, rl), rv, rr);
			else
			{
				T1 rlv = (T1)l.getVal();
				Node<T1> rll = rl.getLeft();
				Node<T1> rlr = rl.getRight();
				return Make(Make(l, v, rll), rlv, Make(rlr, rv, rr));
			}
		}
		else if (hl > hr + 1)
		{
			T1 lv = (T1)l.getVal();
			Node<T1> ll = l.getLeft();
			Node<T1> lr = l.getRight();
			if (Height(ll) >= Height(lr))
				return Make(ll ,lv, Make(lr, v, r));
			else
			{
				T1 lrv = (T1)lr.getVal();
				Node<T1> lrl = lr.getLeft();
				Node<T1> lrr = lr.getRight();
				return Make(Make(ll, lv, lrl), lrv, Make(lrr, v, r));
			}
		}
		else return Make(l, v, r);
	}

	private Node<T1> AddF(Node<T1> akt, T1 w)
	{
		if (akt == null)
			return Make(null, w, null);

		Integer cmp = w.compareTo((T1)akt.getVal());
		if (cmp < 0)
		{
			Node<T1> nl = AddF(akt.getLeft(), w);
			return Balance(nl, (T1)akt.getVal(), akt.getRight());
		}
		else if (cmp > 0)
		{
			Node<T1> nr = AddF(akt.getRight(), w);
			return Balance(akt.getLeft(), (T1)akt.getVal(), nr);
		}
		else return akt;
	}

	private Node<T1> RemoveMin(Node<T1> akt)
	{
		Node<T1> l = akt.getLeft();
		Node<T1> r = akt.getRight();
		T1 v = (T1)akt.getVal();
		if (l == null)
			return r;
		else return Balance(RemoveMin(l), v, r);
	}

	private T1 GetMin(Node<T1> akt)
	{
		Node<T1> l = akt.getLeft();
		if (l == null)
			return akt.getVal();
		else return (T1)GetMin(l);
	}

	private Node<T1> Merge(Node<T1> l, Node<T1> r)
	{
		if (l == null)
			return r;
		else if (r == null)
			return l;
		else
		{
			T1 minim = (T1)GetMin(r);
			return Balance(l, minim, RemoveMin(r));
		}
	}

	private Node<T1> RemoveF(Node<T1> akt, T1 w)
	{
		if (akt == null)
			return null;

		Node<T1> l = akt.getLeft();
		Node<T1> r = akt.getRight();
		T1 v = (T1)akt.getVal();
		Integer cmp = w.compareTo((T1)akt.getVal());
		if (cmp < 0)
			return Balance(RemoveF(l, w), v, r);
		else if (cmp > 0)
			return Balance(l, v, RemoveF(r, w));
		else return Merge(l, r);
	}

	private void PrintF(Node<T1> akt)
	{
		if (akt == null)
			return;

		Node<T1> l = akt.getLeft();
		Node<T1> r = akt.getRight();

		PrintF(l);

		System.out.println(akt.getVal());

		PrintF(r);
	}

	public void Add(T1 str) //funkcja dodajaca obiekt do bst
	{
		this.root = AddF(this.root, str);
	}

	public void Remove(T1 str) //funkcja usuwajaca obiekt z bst
	{
		this.root = RemoveF(this.root, str);
	}

	public void Print() //funkcja wypisujaca posortowane obiekty z bst
	{
		PrintF(this.root);
	}
}