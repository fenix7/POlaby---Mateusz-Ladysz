import java.util.Scanner;

class belki {
	public static void main(String args[])  
	{
        Scanner scanner = new Scanner(System.in);
        int n;
        n = scanner.nextInt();
        int[][] dp = new int[55][55];
        int[] tab = new int[55];
        while(n != 0)
        {
            int k = scanner.nextInt();
            for(int i = 1; i <= k + 1; i++)
            {
                for(int j = 1; j <= k + 1; j++)
                    dp[i][j]=100000000;
            }
            for(int i = 1; i <= k ;i++)
                tab[i] = scanner.nextInt();
            tab[k + 1] = n;
            for(int i = k + 1; i >= 1; i --)
                dp[i][i] = 0;       
            for(int i = 2; i <= k + 1; i++)
            {
                for(int j = 1; j + i - 1 <= k + 1; j++)
                {
                    for(int h = j; h < j + i - 1; h++)
                    {
                        if(dp[j][h] + dp[h + 1][j + i - 1] + tab[j + i - 1] - tab[j - 1] < dp[j][j + i - 1])
                            dp[j][j + i - 1] = dp[j][h] + dp[h + 1][j + i - 1] + tab[j + i - 1] - tab[j - 1];
                    }
                } 
            }
            System.out.print("The minimum cutting is ");
            System.out.print(dp[1][k + 1]);
            System.out.println(".");
            //System.out.println(dp[1][k + 1]);
            n = scanner.nextInt();
        }
	}
} 