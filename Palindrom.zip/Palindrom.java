import java.util.Scanner;

public class Palindrom
{
	public static boolean czy_pal(String s1)
	{
		for (int i = 0; i < s1.length(); i++)
		{
			if (s1.charAt(i) != s1.charAt(s1.length() - i - 1))
				return false;
		}
		return true;
	}

	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		boolean ok = czy_pal(scan.nextLine());
		if (ok == true)
			System.out.println("TAK");
		else
			System.out.println("NIE");
	}
}