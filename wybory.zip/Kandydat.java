public class Kandydat
{
	private String partia;
	private String imie;
	private String nazwisko;
	private String plec;
	private int glosy;

	public Kandydat(String partia, String imie, String nazwisko, String plec)
	{
		this.partia = partia;
		this.imie = imie;
		this.nazwisko = nazwisko;
		this.plec = plec;
	}

	public String getPartia()
	{
		return this.partia;
	}

	public String getImie()
	{
		return this.imie;
	}

	public String getNazwisko()
	{
		return this.nazwisko;
	}

	public String getPlec()
	{
		return this.plec;
	}

	public int getGlosy()
	{
		return this.glosy;
	}





	public void addGlos()
	{
		this.glosy++;
	}
}