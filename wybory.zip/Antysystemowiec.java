import java.util.ArrayList;
import java.util.Random;

public class Antysystemowiec extends Wyborca
{
	public Kandydat oddaj_glos(ArrayList<Kandydat> lista)
	{
		ArrayList<Kandydat> lista2 = new ArrayList<Kandydat>();
		Random r = new Random();
		int los = r.nextInt(2);
		if (los == 0) return null;

		for (int i = 0; i < lista.size(); i++)
		{
			Kandydat akt = lista.get(i);
			if (akt.getPartia().equals("Independent")) lista2.add(akt);
		}

		if (lista2.size() == 0) return null;

		int a = r.nextInt(lista2.size());
		Kandydat dod = lista2.get(a);

		return dod;
	}
}