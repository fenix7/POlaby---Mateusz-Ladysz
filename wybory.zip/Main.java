import java.util.ArrayList;

public class Main
{
	public static void main(String[] args)
	{
		ArrayList<Kandydat> kandydaci = new ArrayList<Kandydat>();
		Kandydat k1 = new Kandydat("PIS", "Andrzej", "Duda", "Man");
		Kandydat k2 = new Kandydat("PO", "Bronislaw", "Komorowski", "Man");
		Kandydat k3 = new Kandydat("SLD", "Magdalena", "Ogorek", "Woman");
		Kandydat k4 = new Kandydat("PIS", "Jaroslaw", "Kaczynski", "Man");
		Kandydat k5 = new Kandydat("Independent", "Jakas", "Kobieta", "Woman");
		Kandydat k6 = new Kandydat("Independent", "Pawel", "Kukiz", "Man");
		kandydaci.add(k1);
		kandydaci.add(k2);
		kandydaci.add(k3);
		kandydaci.add(k4);
		kandydaci.add(k5);
		kandydaci.add(k6);

		ArrayList<Wyborca> wyborcy = new ArrayList<Wyborca>();
		Wyborca w1 = new Partyjniak("PIS");
		Wyborca w2 = new Znudzony();
		Wyborca w3 = new Feminista();
		Wyborca w4 = new Antysystemowiec();
		Wyborca w5 = new Antysystemowiec();
		Wyborca w6 = new Partyjniak("PO");
		wyborcy.add(w1);
		wyborcy.add(w2);
		wyborcy.add(w3);
		wyborcy.add(w4);
		wyborcy.add(w5);
		wyborcy.add(w6);


		Wybory wybory = new Wybory(kandydaci, wyborcy);
		wybory.przeprowadz_wybory();
		wybory.giveResults();
	}
}