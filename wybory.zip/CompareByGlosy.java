import java.util.*;
import java.lang.*;
import java.io.*;

public class CompareByGlosy implements Comparator<Kandydat> 
{
	public int compare(Kandydat k1, Kandydat k2)
	{
		return k2.getGlosy() - k1.getGlosy();
	}
}