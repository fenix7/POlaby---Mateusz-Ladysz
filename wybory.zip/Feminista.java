import java.util.ArrayList;
import java.util.Collections;
import java.util.*;
import java.lang.*;
import java.io.*;

public class Feminista extends Wyborca
{
	public Kandydat oddaj_glos(ArrayList<Kandydat> lista)
	{
		ArrayList<Kandydat> lista2 = new ArrayList<Kandydat>();
		for (int i = 0; i < lista.size(); i++)
		{
			Kandydat akt = lista.get(i);
			if (akt.getPlec().equals("Woman")) lista2.add(akt);
		}

		if (lista2.size() == 0) return null;

		Collections.sort(lista2, new CompareByNazwisko());

		Kandydat dod = lista2.get(0);
		return dod;
	}

}