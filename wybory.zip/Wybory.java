import java.util.ArrayList;
import java.util.Collections;

public class Wybory
{
	private ArrayList<Kandydat> kandydaci;
	private ArrayList<Wyborca> wyborcy;
	private double dobre_glosy;
	private double wszystkie_glosy;

	public Wybory(ArrayList<Kandydat> kandydaci, ArrayList<Wyborca> wyborcy)
	{
		this.kandydaci = kandydaci;
		this.wyborcy = wyborcy;
	}

	public void przeprowadz_wybory()
	{
		for (int i = 0; i < wyborcy.size(); i++)
		{
			Wyborca akt = wyborcy.get(i);
			Kandydat dod = akt.oddaj_glos(kandydaci);
			if (dod != null)
			{
				this.dobre_glosy += 1.00;
				dod.addGlos();
			}

			this.wszystkie_glosy += 1.00;
		}
	}

	public void giveResults()
	{
		double wynik = Math.round(this.dobre_glosy/this.wszystkie_glosy * 100.00 * 100.00);
		System.out.println("Turnout " + wynik / 100.00 + "%");
		Collections.sort(kandydaci, new CompareByGlosy());
		for (int i = 0; i < kandydaci.size(); i++)
		{
			Kandydat akt = kandydaci.get(i);
			wynik = Math.round(akt.getGlosy()/this.dobre_glosy * 100.00 * 100.00);
			System.out.println(akt.getNazwisko() + "(" + akt.getPartia() + ") : " + wynik / 100.00 + "%");
		}
	}
}