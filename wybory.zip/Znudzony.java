import java.util.ArrayList;

public class Znudzony extends Wyborca
{
	public Kandydat oddaj_glos(ArrayList<Kandydat> lista)
	{
		return null;
	}
}