import java.util.ArrayList;

public abstract class Wyborca
{
	public abstract Kandydat oddaj_glos(ArrayList<Kandydat> lista);
}