import java.util.*;
import java.lang.*;
import java.io.*;

public class CompareByNazwisko implements Comparator<Kandydat> 
{
	public int compare(Kandydat k1, Kandydat k2)
	{
		return k1.getNazwisko().compareTo(k2.getNazwisko());
	}
}