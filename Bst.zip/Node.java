public class Node
{
	private Node left;
	private Node right;
	private String val;
	private Integer height;

	public Node(Node l, String str, Node r, Integer h)
	{
		this.left = l;
		this.val = str;
		this.right = r;
		this.height = h;
	}

	public Node getLeft()
	{
		return this.left;
	}

	public void setLeft(Node l)
	{
		this.left = l;
	}

	public Node getRight()
	{
		return this.right;
	}

	public void setRight(Node r)
	{
		this.right = r;
	}

	public String getVal()
	{
		return this.val;
	}

	public void setVal(String v)
	{
		this.val = v;
	}

	public Integer getHeight()
	{
		return this.height;
	}

	public void setHeight(Integer h)
	{
		this.height = h;
	}

	public Node()
	{
		this.left = null;
		this.right = null;
		this.val = "";
		this.height = 0;
	}


}