public class Bst
{
	private Node root;

	public Bst()
	{
		this.root = null;
	}

	public Node getRoot()
	{
		return this.root;
	}

	public void setRoot(Node r)
	{
		this.root = r;
	}

	public Integer Max(Integer a, Integer b)
	{
		if (a > b)
			return a;
		else return b;
	}

	public Integer Height(Node akt)
	{
		if (akt == null)
			return 0;
		else return akt.getHeight();
	}

	private Node Make(Node l, String v, Node r)
	{
		Node nn = new Node(l, v, r, Max(Height(l), Height(r)) + 1);
		return nn;
	}

	private Node Balance(Node l, String v, Node r)
	{
		Integer hl = Height(l);
		Integer hr = Height(r);
		if (hr > hl + 1)
		{
			String rv = r.getVal();
			Node rl = r.getLeft();
			Node rr = r.getRight();
			if (Height(rr) >= Height(rl))
				return Make(Make(l, v, rl), rv, rr);
			else
			{
				String rlv = rl.getVal();
				Node rll = rl.getLeft();
				Node rlr = rl.getRight();
				return Make(Make(l, v, rll), rlv, Make(rlr, rv, rr));
			}
		}
		else if (hl > hr + 1)
		{
			String lv = l.getVal();
			Node ll = l.getLeft();
			Node lr = l.getRight();
			if (Height(ll) >= Height(lr))
				return Make(ll ,lv, Make(lr, v, r));
			else
			{
				String lrv = lr.getVal();
				Node lrl = lr.getLeft();
				Node lrr = lr.getRight();
				return Make(Make(ll, lv, lrl), lrv, Make(lrr, v, r));
			}
		}
		else return Make(l, v, r);
	}

	private Node AddF(Node akt, String w)
	{
		if (akt == null)
			return Make(null, w, null);

		Integer cmp = w.compareTo(akt.getVal());
		if (cmp < 0)
		{
			Node nl = AddF(akt.getLeft(), w);
			return Balance(nl, akt.getVal(), akt.getRight());
		}
		else if (cmp > 0)
		{
			Node nr = AddF(akt.getRight(), w);
			return Balance(akt.getLeft(), akt.getVal(), nr);
		}
		else return akt;
	}

	private Node RemoveMin(Node akt)
	{
		Node l = akt.getLeft();
		Node r = akt.getRight();
		String v = akt.getVal();
		if (l == null)
			return r;
		else return Balance(RemoveMin(l), v, r);
	}

	public String GetMin(Node akt)
	{
		Node l = akt.getLeft();
		if (l == null)
			return akt.getVal();
		else return GetMin(l);
	}

	private Node Merge(Node l, Node r)
	{
		if (l == null)
			return r;
		else if (r == null)
			return l;
		else
		{
			String minim = GetMin(r);
			return Balance(l, minim, RemoveMin(r));
		}
	}

	private Node RemoveF(Node akt, String w)
	{
		if (akt == null)
			return null;

		Node l = akt.getLeft();
		Node r = akt.getRight();
		String v = akt.getVal();
		Integer cmp = w.compareTo(akt.getVal());
		if (cmp < 0)
			return Balance(RemoveF(l, w), v, r);
		else if (cmp > 0)
			return Balance(l, v, RemoveF(r, w));
		else return Merge(l, r);
	}

	private void PrintF(Node akt) //funckja wypisujaca stringi posortowane leksykograficznie
	{
		if (akt == null)
			return;

		Node l = akt.getLeft();
		Node r = akt.getRight();

		PrintF(l);

		System.out.println(akt.getVal());

		PrintF(r);
	}

	public void Add(String str) //funkcja dodajaca string do bst
	{
		this.root = AddF(this.root, str);
	}

	public void Remove(String str) //funkcja usuwajaca string z bst
	{
		this.root = RemoveF(this.root, str);
	}

	public void Print()
	{
		PrintF(this.root);
	}
}