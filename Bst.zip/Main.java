public class Main
{
	public static void main(String[] args)
	{
		//przyklad wywolania funkcji add, remove, print
		Bst tree = new Bst();
		System.out.println(tree.getRoot());
		tree.Add("a");
		tree.Add("b");
		tree.Add("c");
		tree.Remove("a");
		tree.Add("a");
		tree.Add("a");
		tree.Add("abb");
		tree.Remove("b");
		tree.Add("b");
		tree.Remove("abb");
		tree.Remove("a");
		tree.Remove("c");
		tree.Remove("b");
		tree.Remove("a");



		tree.Print();
	}
}
