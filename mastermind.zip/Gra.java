public class Gra
{
	private int ilosc_rund;

	public Gra(int ilosc_rund)
	{
		this.ilosc_rund = ilosc_rund;
	}

	public String Rozgrywka() //rozgrywka
	{
		Gracz gracz1 = new Gracz();
		Gracz gracz2 = new Gracz();

		for (int j = 1; j <= this.ilosc_rund; j++)
		{
			if (j % 2 == 1)
			{
				String odp = gracz1.stworz();
				System.out.println("KOD Gracza1 wybrany.");
				System.out.println();

				for (int i = 1; i <= 10; i++)
				{
					System.out.println("Proba " + i);

					System.out.print("Gracz2 zgaduje : ");

					String kand = gracz2.zgaduj();

					String inf_zwrotna = gracz1.odpowiedz(odp, kand);

					System.out.println("Gracz1 odpowiada : " + inf_zwrotna);

					System.out.println();

					if (inf_zwrotna.equals("1 1 1 1"))
					{
						System.out.println("Gracz2 udzielil prawidlowej odpowiedzi");
						break;
					}
					gracz1.dodajPunkt();

					if (i == 10)
					{
						gracz1.dodajPunkt();
						System.out.println("Gracz1 wygral runde");
					}
				}
			}
			else
			{
				String odp = gracz2.stworz();
				System.out.println("KOD Gracza2 wybrany.");
				System.out.println();

				for (int i = 1; i <= 10; i++)
				{
					System.out.println("Proba " + i);

					System.out.print("Gracz1 zgaduje : ");

					String kand = gracz1.zgaduj();

					String inf_zwrotna = gracz2.odpowiedz(odp, kand);

					System.out.println("Gracz2 odpowiada : " + inf_zwrotna);

					System.out.println();

					if (inf_zwrotna.equals("1 1 1 1"))
					{
						System.out.println("Gracz1 udzielil prawidlowej odpowiedzi");
						break;
					}
					gracz2.dodajPunkt();

					if (i == 10)
					{
						gracz2.dodajPunkt();
						System.out.println("Gracz2 wygral runde");
					}
				}
			}

			System.out.println();
		}

		System.out.println("Gracz1 : " + gracz1.getPunkty() + " punktow.");
		System.out.println("Gracz2 : " + gracz2.getPunkty() + " punktow.");
		if (gracz1.getPunkty() == gracz2.getPunkty())
		{
			return "REMIS";
		}
		else if (gracz1.getPunkty() > gracz2.getPunkty())
		{
			return "Gracz1 wygral";
		}
		else
		{
			return "Gracz2 wygral";
		}
	}
}