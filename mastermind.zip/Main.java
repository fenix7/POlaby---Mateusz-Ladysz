public class Main
{
	public static void main(String[] args)
	{
		//przykladowa rozgrywka na 2 rundy
		Gra gra = new Gra(2);
		String wynik = gra.Rozgrywka();
		System.out.println(wynik);
	}
}