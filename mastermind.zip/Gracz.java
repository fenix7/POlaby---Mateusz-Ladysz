import java.util.Random;
import java.util.Scanner;

public class Gracz
{
	private int punkty;

	public Gracz()
	{
		this.punkty = 0;
	}

	public void dodajPunkt()
	{
		this.punkty++;
	}

	public int getPunkty()
	{
		return this.punkty;
	}

	public String zgaduj() //zgadywanie kodu innego gracza
	{
		Scanner scan = new Scanner(System.in);
		String s = new String();
		for (int i = 0; i <= 3; i++)
		{
			int a = scan.nextInt();
			if (s.length() > 0) s = s + ' ';
			char dod = Character.forDigit(a, 10);
			s = s + a;
		}
		return s;
	}


	public String odpowiedz(String odp, String kand) // wartosc 1 odpowiada czarnej szpilce, a 0 bialej
	{
		String s = new String();
		int[] zl = new int[6];
		for (int i = 0; i <= 6; i += 2)
		{
			zl[Integer.parseInt(String.valueOf(odp.charAt(i)))]++;
		}
		for (int i = 0; i <= 6; i += 2)
		{
			if (odp.charAt(i) == kand.charAt(i))
			{
				if (s.length() != 0) s = s + ' ';
				s = s + '1';
			}
			else if (zl[Integer.parseInt(String.valueOf(kand.charAt(i)))] > 0)
			{
				if (s.length() != 0) s = s + ' ';
				s = s + '0';
			}
		}
		return s;
	}

	public String stworz() //losowe wybieranie kodu przez gracza
	{
		String s = new String();
		for (int i = 0; i <= 3; i++)
		{
			Random r = new Random();
			int a = r.nextInt(6);
			if (s.length() > 0) s = s + ' ';
			char dod = Character.forDigit(a, 10);
			s = s + a;
		}
		return s;
	}
}